
#client
# Project 2 
# Develop a client-server application where the client authenticates itself, 
# performs file upload/download operations, and implements a CRC (Cyclic Redundancy Check) 
# for data transmission using socket programming.
# Name: Jatin K rai
#DawID


import socket
import binascii

#Helper message to calcualte CRC.
def mycrc16(data: bytes, poly=0x1021):
    crc = 0xFFFF
    for byte in data:
        crc ^= byte << 8
        for _ in range(8):
            if crc & 0x8000:
                crc = (crc << 1) ^ poly
            else:
                crc <<= 1
            crc &= 0xFFFF
    return crc

def proj2SockServer_start():
    try:
        host = 'localhost'
        port = 8080

        while True:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as myjatinSockerServer:
                myjatinSockerServer.bind((host, port))
                myjatinSockerServer.listen()
                print('DS Project2 Server listening on', host, port)
                conn, addr = myjatinSockerServer.accept()
                with conn:
                    print('Connected by client with address', addr)
                    data = conn.recv(1024)
                    if data:
                        message = data[:-2]
                        received_crc = int.from_bytes(data[-2:], 'big')
                        calculated_crc = mycrc16(message)
                        if received_crc == calculated_crc:
                            response = 'This is Good data'
                        else:
                            response = 'This is Bad data'
                        conn.sendall(response.encode())

                command = input("Do you want to continue (yes/no)?")
                if(command.lower() == "no"):
                    break
                else:
                    continue
    except Exception as error:
        print(f"project2 Socker Server: proj2SockServer_start() error: {error}")

if __name__ == '__main__':
    proj2SockServer_start()

