
#client
# Project 2 
# Develop a client-server application where the client authenticates itself, 
# performs file upload/download operations, and implements a CRC (Cyclic Redundancy Check) 
# for data transmission using socket programming.
# Name: Jatin K rai
#DawID


import socket
import binascii

#Helper message to calcualte CRC.
def mycrc16(data: bytes, poly=0x1021):
    crc = 0xFFFF
    for byte in data:
        crc ^= byte << 8
        for _ in range(8):
            if crc & 0x8000:
                crc = (crc << 1) ^ poly
            else:
                crc <<= 1
            crc &= 0xFFFF
    return crc

def proj2Sockclient_start():
    try:

        host = 'localhost'
        port = 8080

        message = b'Hello, Server!'
        crc = mycrc16(message)
        message_with_crc = message + crc.to_bytes(2, 'big')

        while True:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as myjatinSockerClient:
                myjatinSockerClient.connect((host, port))
                myjatinSockerClient.sendall(message_with_crc)
                response = myjatinSockerClient.recv(1024)
                print('Received from DS project 2 server:', response.decode())
            
                command = input("Do you want to continue (yes/no)?")
                if(command.lower() == "no"):
                    break
                else:
                    continue
    except Exception as error:
        print(f"project2 Socker Client proj2Sockclient_start() error: {error}")

if __name__ == '__main__':
    proj2Sockclient_start()