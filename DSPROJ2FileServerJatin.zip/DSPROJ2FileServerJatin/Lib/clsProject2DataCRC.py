# Project 2 
# Develop a client-server application where the client authenticates itself, 
# performs file upload/download operations, and implements a CRC (Cyclic Redundancy Check) 
# for data transmission using socket programming.
# Name: Jatin K rai
#DawID
"""
Data Integrity Check using CRC (16-bit): 

        Write a client-server program that implements CRC (Cyclic Redundancy Check) for verifying data integrity. Follow these steps:
        Client-Side CRC: The client sends a message to the server with an appended CRC (16-bit) checksum.
        Server-Side CRC Check: The server checks the received data for errors using the shared CRC divisor.
        Based on the result, the server responds with either good data (if no errors) or bad data (if errors are detected).

        Note: Both the server and client must share a common divisor for CRC computation.
"""
import binascii


# Create a class
class clsProject2DataCRC():
       #Constuctor
    def __init__(self):
        self.MyCurrentProcessName = "P"
        self.message_with_crc = ""

    #Used by Server
    def ServerFilecrc32(self, data, myprocessname):
        self.MyCurrentProcessName = myprocessname
        response = ""
        try:
            print(f"clsProject2DataCRC(): ServerFilecrc32() : for Process : {self.MyCurrentProcessName} function started.")
           
            if (len(data) > 0):
                    message = data[:-2]
                    received_crc = int.from_bytes(data[-2:], 'big')
                    calculated_crc = self.mycrc16(message)

                    if received_crc == calculated_crc:
                        response = 'Good data'
                    else:
                        response = 'Bad data'
            print(f"clsProject2DataCRC(): ServerFilecrc32() : for Process : {self.MyCurrentProcessName} function completed.")
        except Exception as error:
            print(f"clsProject2DataCRC: ServerFilecrc32():  error : {error}")
        return response

    #used by Client.
    def ClientFilecrc32(self, command, myprocessname):
        self.MyCurrentProcessName = myprocessname

        try:
            print(f"clsProject2DataCRC(): ClientFilecrc32() : for Process : {self.MyCurrentProcessName} function started.")
            
            strmessages = command.split(' ')
            message = ""

            if(len(strmessages) > 0):
                for index in range(1, len(strmessages)):
                    message = message + " " + strmessages[index]
            else:
                message = input("Enter message to check: ")

            if (len(message) > 0):
                message = message.strip()
                encoded= message.encode('utf-8')
                mycrcval = self.myJitcrc16(encoded)
                self.message_with_crc = encoded + mycrcval.to_bytes(2, 'big')

            print(f"clsProject2DataCRC(): ClientFilecrc32() : for Process : {self.MyCurrentProcessName} function completed.")
        except Exception as error:
            print(f"clsProject2DataCRC: ClientFilecrc32():  error : {error}")
        return self.message_with_crc


    #Helper message to calcualte CRC.
    def mycrc16(data, poly=0x1021):
        print(f"clsProject2DataCRC(): mycrc16() :  function started.")
        crc = 0xFFFF
        data = bytearray(data)
        for byte in data:
            crc ^= byte << 8
            for _ in range(8):
                if crc & 0x8000:
                    crc = (crc << 1) ^ poly
                else:
                    crc <<= 1
                crc &= 0xFFFF
        print(f"clsProject2DataCRC(): mycrc16() :  function completed.")
        return crc
    