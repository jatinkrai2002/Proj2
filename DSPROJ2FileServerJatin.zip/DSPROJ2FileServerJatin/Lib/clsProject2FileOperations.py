# Project 2 
# Develop a client-server application where the client authenticates itself, 
# performs file upload/download operations, and implements a CRC (Cyclic Redundancy Check) 
# for data transmission using socket programming.
# Name: Jatin K rai
#DawID

"""
File Operations: After authentication, the client can choose one of the following options:

        Download a File:
            The client sends a command to download a file from the server: get <filename>
            Ensure files are stored in different directories on the client and server sides.

        Upload a File:
            The client sends a command to upload a file to the server: put <filename>
            Use separate directories for file management between the client and server.
"""
import Pyro5.api
import os
import zlib
import logging
import random
from Lib.clsProject2Authentication import clsProject2Authentication
from Lib.clsProject2DataCRC import clsProject2DataCRC

@Pyro5.api.expose
class clsProject2FileOperations():

    ServerOTP = ""

    # assign
    def __init__(self):
        self.password = "server_password"
        self.files_dir = "server_files"
        self.client_dir = "client_files"
        if not os.path.exists(self.files_dir):
            os.makedirs(self.files_dir)
        logging.info("File server initialized.")
        self.ServerOTP = ""
        self.Authentication = clsProject2Authentication()
        self.MyCurrentProcessName = "P"

    @Pyro5.api.expose
    def get_file(self, filename):
        print(f"clsProject2FileOperations(): get_file() : function started.")
        try:
            filepath = os.path.join(self.files_dir, filename)
            if os.path.exists(filepath):
                with open(filepath, 'rb') as f:
                    data = f.read()
                #CRC calculation,
                crc = zlib.crc32(data) & 0xFFFF
                logging.info(f"File {filename} sent to client with CRC {crc}.")
                print(f"clsProject2FileOperations(): get_file() : for Process : {self.MyCurrentProcessName} function completed.")
                return data, crc
            else:
                logging.warning(f"File {filename} not found.")
                print(f"clsProject2FileOperations(): get_file() : for Process : {self.MyCurrentProcessName} function completed.")
                return None, None
        except Exception as e:
            logging.error(f"Error in get_file: {e}")
            return None, None
        


    @Pyro5.api.expose
    def put_file(self, filename, data, crc):

        print(f"clsProject2FileOperations(): put_file() : function started.")
        try:
            if zlib.crc32(data) & 0xFFFF == crc:
                filepath = os.path.join(self.files_dir, filename)
                with open(filepath, 'wb') as f:
                    f.write(data)
                logging.info(f"File {filename} uploaded successfully with CRC {crc}.")
                print(f"clsProject2FileOperations(): put_file() : for Process : {self.MyCurrentProcessName} function completed.")
                return "File uploaded successfully"
            else:
                logging.warning("CRC check failed for uploaded file.")
                print(f"clsProject2FileOperations(): put_file() : for Process : {self.MyCurrentProcessName} function completed.")
                return "CRC check failed"
        except Exception as e:
            logging.error(f"Error in put_file: {e}")
            return "Error in file upload"
        

    @Pyro5.api.expose        
    def download_file(self, command, MyProcessName):
        self.MyCurrentProcessName = MyProcessName
        print(f"clsProject2FileOperations(): download_file() : for Process : {self.MyCurrentProcessName} function started with command = {command}")

        strfilename = command.split(' ')

        if(len(strfilename) > 0):
            filename =  strfilename[1]
        else:
            filename = input("Enter filename to download: ")
        try:
            #CRC check
            data, crc = self.get_file(filename)
            
            if data:
                self.client_dir = "client_files"
                if not os.path.exists(self.client_dir):
                    os.makedirs(self.client_dir)
                with open(os.path.join(self.client_dir, filename), 'wb') as f:
                    f.write(data)
                logging.info(f"File {filename} downloaded successfully with CRC {crc}.")
                print(f"clsProject2FileOperations(): download_file() : for Process : {self.MyCurrentProcessName} function completed.")
            else:
                logging.warning("File not found on server.")
                print(f"clsProject2FileOperations(): download_file() : for Process : {self.MyCurrentProcessName} function completed.")
        except Exception as e:
            logging.error(f"Error in download_file: {e}")



    @Pyro5.api.expose
    def upload_file(self, command, MyProcessName):
        self.MyCurrentProcessName = MyProcessName
        print(f"clsProject2FileOperations(): upload_file() : for Process : {self.MyCurrentProcessName} function started with command = {command}.")

        strfilename = command.split(' ')

        if(len(strfilename) > 0):
            filename =  strfilename[1]
        else:
            filename = input("Enter filename to download: ")

        self.client_dir = "client_files"
        filepath = os.path.join(self.client_dir, filename)
        try:
            with open(filepath, 'rb') as f:
                data = f.read()
            crc = zlib.crc32(data) & 0xFFFF
            #CRC check
            response = self.put_file(filename, data, crc)
            logging.info(response)
        except FileNotFoundError:
            logging.warning("File not found on client.")
        except Exception as e:
            logging.error(f"Error in upload_file: {e}")
        print(f"clsProject2FileOperations(): upload_file() :for Process : {self.MyCurrentProcessName} function completed.")


    @Pyro5.api.expose
    def getOTP(self, MyProcessName):
        self.MyCurrentProcessName = MyProcessName
        print(f"clsProject2FileOperations(): getOTP() : for Process : {self.MyCurrentProcessName} function started.")
        try:
            #Authentication service provide OTP to the client.
            self.ServerOTP = self.Authentication.getOTP()
            print(f"clsProject2FileOperations(): getOTP() : for Process : {self.MyCurrentProcessName} function completed with {self.ServerOTP}.")
            return self.ServerOTP
        except Exception as error:
            logging.warning(f"OTP generation error : {error}")


    @Pyro5.api.expose
    def sendHiToServer (self, Icebreakmessage, MyProcessName):
        self.MyCurrentProcessName = MyProcessName
        print(f"clsProject2FileOperations(): sendHiToServer() : for Process : {self.MyCurrentProcessName} function started.")
        try:
            
            print(f"Thanks and Server recevied message : {Icebreakmessage} from Process : {self.MyCurrentProcessName}.")
            response = "Hello from Server"
            print(f"clsProject2FileOperations(): sendHiToServer(): for Process : {self.MyCurrentProcessName} function completed .")
            return response
        except Exception as error:
            logging.warning(f"sendHiToServer error : {error}")

    @Pyro5.api.expose
    def CheckCRCforClientCRCData(self, crcbasedata, MyProcessName):
        self.MyCurrentProcessName = MyProcessName
        print(f"clsProject2FileOperations(): CheckCRCforClientCRCData() : for Process : {self.MyCurrentProcessName} function started.")
        try:
            ServerDataCRC = clsProject2DataCRC()
            response = ServerDataCRC.ServerFilecrc32(crcbasedata, MyProcessName)
            print(f" Server Verified CRC message and received response : {response} from server of  Process : {self.MyCurrentProcessName}.")
            response = "Hello from Server"
            print(f"clsProject2FileOperations(): CheckCRCforClientCRCData(): for Process : {self.MyCurrentProcessName} function completed.")
            return response
        except Exception as error:
            logging.warning(f"CheckCRCforClientCRCData error : {error}")

    


