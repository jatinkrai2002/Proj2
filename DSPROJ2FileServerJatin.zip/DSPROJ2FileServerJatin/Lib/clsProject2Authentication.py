
# Project 2 
# Develop a client-server application where the client authenticates itself, 
# performs file upload/download operations, and implements a CRC (Cyclic Redundancy Check) 
# for data transmission using socket programming.
# Name: Jatin K rai
#DawID
"""
Client Authentication: 

        The client must authenticate by entering a server-defined password (similar to an OTP).

        Upon successful authentication, the client sends a "Hi" message to the server, and the server responds with "Hello."
"""




import logging
import random


class clsProject2Authentication():
    # assign static
    ServerOTP = ""

    #Constuctor
    def __init__(self):
        self.ServerOTP = ""
        self.password = "Hello"

    #password based.
    def authenticateClient(self, password):
        print(f"clsProject2Authentication(): authenticateClient() : function started.")
        if password == self.password:
            logging.info("Client authenticated successfully.")
            print(f"clsProject2Authentication(): authenticateClient() : function completed.")
            return "Hello"
        else:
            logging.warning("Client authentication failed.")
            print(f"clsProject2Authentication(): authenticateClient() : function completed.")
            return "Authentication Failed"

    #password based
    def authenticateServer(self):
        print(f"clsProject2Authentication(): authenticateServer() : function started.")
        
        #simple Hello world password
        # self.password = input("Enter password: ")                
        response = self.password
        if response == "Hello":
            logging.info("Authenticated successfully.")
            print(f"clsProject2Authentication(): authenticateServer() : function completed.")
            return True
        else:
            logging.warning("Authentication failed.")
            print(f"clsProject2Authentication(): authenticateServer() : function completed.")
            return False
   
    #OTP based
    def getOTP(self):
        print(f"clsProject2Authentication():: getOTP() : function started.")
        try:
            otp = ""
            for num in range(6):
                otp += str(random.randint(0,9))
            self.ServerOTP = otp
            print(f"clsProject2Authentication():: getOTP() : function completed with {self.ServerOTP}.")
            return self.ServerOTP
        except Exception as error:
            logging.warning(f"OTP generation error : {error}")
    