# Project 2 
# Develop a client-server application where the client authenticates itself, 
# performs file upload/download operations, and implements a CRC (Cyclic Redundancy Check) 
# for data transmission using socket programming.
# Name: Jatin K rai
#DawID



import sys
import os
import zlib
import logging
import threading

class URLHelper:

    URIValue = ""

    def __init__(self, currentRLFolderFileName) -> None:
        self.URIValue = ""
        self.ServerURLPath = currentRLFolderFileName
        self.MyCurrentProcessName = "P"
   
    def show_help(self, command, myprocessname):
        self.MyCurrentProcessName = myprocessname

        print(f"clsProject2FileOperations(): show_help() : for Process : {self.MyCurrentProcessName} function started with command = {command}.")
        print("""
        Available commands:
        get <filename>  - Download a file from the server
        put <filename>  - Upload a file to the server
        crc <message>   - Verify with CRC16 server
        exit            - Exit the application
        """)
        print(f"clsProject2FileOperations(): uploshow_helpad_file() : for Process : {self.MyCurrentProcessName} function completed with command = {command}.")

    def readserverURLFile(self):
        try:
            # Open function to open the file
            # (same directory) in append mode and
            URLfile1 = open(self.ServerURLPath,"r+")
           

            for line in URLfile1:
                # Print each line
                self.URIValue = line.strip()
                print(self.URIValue)

            #self.URIValue = URLfile1.readline(1)
            print(f"Server URI Value is : {self.URIValue}")
            URLfile1.close()
            return self.URIValue
        except Exception as error:
            print(f"Error occured in the URLHelper. readserverURLFie() with error : {error}")

    def writeServerURLFile(self, URLValue):
        try:
            # store its reference in the variable file1
            # and "MyFile2.txt" in D:\Text in file2
            self.URIValue = URLValue
            URLfile2 = open(self.ServerURLPath,"w+")
            URLfile2.writelines(URLValue) 
            URLfile2.close() 
            print(f"Server URI Value is : {self.URIValue} into the File : {self.ServerURLPath} ") 
        except Exception as error:
            print(f"Error occured in the URLHelper. WriteserverURLFie() with error : {error}")