
# Project 2 
# Develop a client-server application where the client authenticates itself, 
# performs file upload/download operations, and implements a CRC (Cyclic Redundancy Check) 
# for data transmission using socket programming. 
# Name: Jatin K rai
#DawID

"""
 Connection Persistence:
 The connection should remain active until the client explicitly decides to terminate it.

"""

# Create a
class clsProject2ConnectionPersistence():
    #Constuctor
    def __init__(self):
        self.MyCurrentProcessName = "P"
        
    def IsConnectionExist(self, command, myprocessname):
       
        self.MyCurrentProcessName = myprocessname
        print(f"clsProject2FileOperations(): IsConnectionExist() : for Process : {self.MyCurrentProcessName} function started with command = {command}.")
        
        if (command.lower() == "exit"):
            print(f"clsProject2FileOperations(): IsConnectionExist() : for Process : {self.MyCurrentProcessName} function completed with command = {command}.")
