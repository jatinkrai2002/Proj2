#client
# Project 2 
# Develop a client-server application where the client authenticates itself, 
# performs file upload/download operations, and implements a CRC (Cyclic Redundancy Check) 
# for data transmission using socket programming.
# Name: Jatin K rai
#DawID

from Lib.URLHelper import URLHelper
from Lib.clsProject2DataCRC import clsProject2DataCRC
from Lib.clsProject2ConnectionPersistence import clsProject2ConnectionPersistence
import Pyro5.api
from pathlib import Path
import os
import zlib
import logging
import threading

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


 #Used by Server
def ServerFilecrc32(data, myprocessname):
    response = ""
    try:
        print(f"client_thread: ServerFilecrc32() : for Process : {myprocessname} function started.")
        
        if (len(data) > 0):
                message = data[:-2]
                received_crc = int.from_bytes(data[-2:], 'big')
                calculated_crc = mycrc16(message)

                if received_crc == calculated_crc:
                    response = 'Good data'
                else:
                    response = 'Bad data'
        print(f"client_thread: ServerFilecrc32() : for Process : {myprocessname} function completed.")
    except Exception as error:
        print(f"client_thread: ServerFilecrc32():  error : {error}")
    return response

#used by Client.
def ClientFilecrc32(command, myprocessname):
    try:
        print(f"client_thread: ClientFilecrc32() : for Process : {myprocessname} function started.")
        
        strmessages = command.split(' ')
        message = ""

        if(len(strmessages) > 0):
            for index in range(1, len(strmessages)):
                message = message + " " + strmessages[index]
        else:
            message = input("Enter message to check: ")

        if (len(message) > 0):
            message = message.strip()
            encoded= message.encode('utf-8')
            mycrcval = mycrc16(encoded)
            message_with_crc = encoded + mycrcval.to_bytes(2, 'big')

        print(f"client_thread: ClientFilecrc32() : for Process : {myprocessname} function completed.")
    except Exception as error:
        print(f"client_thread: ClientFilecrc32():  error : {error}")
    return message_with_crc

    #Helper message to calcualte CRC.
def mycrc16(data, poly=0x1021):
    print(f"client_thread: mycrc16() :  function started.")
    crc = 0xFFFF
    data = bytearray(data)
    for byte in data:
        crc ^= byte << 8
        for _ in range(8):
            if crc & 0x8000:
                crc = (crc << 1) ^ poly
            else:
                crc <<= 1
            crc &= 0xFFFF
    print(f"client_thread mycrc16() :  function completed.")
    return crc


def client_thread(remote_server):

    try:
        MyProcessName = "P0"
        remote_server._pyroClaimOwnership()
        #Get me OTP from Server
        OTPForClient = remote_server.getOTP(MyProcessName)
        print(f"This is your OTP : {OTPForClient} to connect to the project 2 File server")

        #Enter OTP to authenticate with Server
        cliententerOTP = input("Enter File Server provided OTP: ")

        if (cliententerOTP == OTPForClient):
            authenticated  = True
            print(f"OTP is correct and you are connected to the project 2 File server")

            Icebreakmessage = input ("Please enter Hi Message to Server: ")
            
            if (len(Icebreakmessage)> 0):
                print(f"Sendong message : {Icebreakmessage} from Process : {MyProcessName} to Server.")
                response = remote_server.sendHiToServer(Icebreakmessage, MyProcessName)
                print(f"Received message : {response}  to Process : {MyProcessName}.")

            #this is helper class
            clientHelp = URLHelper("URLPath")
            clientPersistance = clsProject2ConnectionPersistence()
            clientCRC = clsProject2DataCRC()
        
            if (authenticated == True):
                while True:
                    command = input("Enter command (get <filename> / put <filename> /crc <messag>/ help / exit): ")
                    if command.startswith("get "):
                        remote_server.download_file(command, MyProcessName)
                    elif command.startswith("put "):
                        remote_server.upload_file(command, MyProcessName)
                    elif command.startswith("crc "):
                        #Data Integrity Check using CRC (16-bit): 
                        crcrequestdata = ClientFilecrc32(command, MyProcessName)
                        response = ServerFilecrc32(crcrequestdata, MyProcessName)
                        print (f" Response for CRC data {response} and request send :{command}")
                    elif command == "help":
                        clientHelp.show_help(command, MyProcessName)
                    elif command == "exit":
                        clientPersistance.IsConnectionExist(command, MyProcessName)
                        break
                    else:
                        logging.warning("Invalid command. Type 'help' for a list of commands.")
            else:
                print(f"OTP is incorrect and reconnect using re run clinet") 
    except Exception as error:
        print(f"client_thread:  error : {error}")


def start_Proejct2Client():
    try:
        MyProcessName = "P0"
        currentworkingdir = os.getcwd()
        """
            data_folder = Path("source_data/text_files/")
            file_to_open = data_folder / "raw_data.txt"
            print(file_to_open.read_text())
        """
        #read url from file
        URLPath = currentworkingdir + "\\ServerOutput\\UrlfileforTimeServer.txt"
        URLFileObj = URLHelper(URLPath)
        uri = URLFileObj.readserverURLFile()

        if ((uri is None) or (len(uri) < 1)):
            uri = input("Enter the UnicastRemoteObject for Project 2 File Server URI: ")

        print (f"URI of the Project 2 File Server URI is : {uri}")    

        print (f" Project 2 File server connected from Client Process : {MyProcessName}") 

        remote_server = Pyro5.api.Proxy(uri)

        client_thread_instance = threading.Thread(target=client_thread, args=(remote_server,))
        client_thread_instance.start()

        print (f" Project 2 File server completed  from Client Process : {MyProcessName}") 

        # remote_process = clsProject2FileOperations(uri,  MyProcessName)
        
    except Exception as error:
            print("Pyro5.api.Proxy(): Project 2 File Server Pyro5.api.Proxy failed while calling")
            print (error)
    finally:
            print("Pyro5.api.Proxy(): Project 2 File Server Pyro5.api.Proxy completed successfully while calling.")


if __name__ == "__main__":
    start_Proejct2Client()
